setInterval(() => {
  console.clear();
  var d = new Date();
  var n = d.toLocaleTimeString();
  console.log(n);
}, 1000);
