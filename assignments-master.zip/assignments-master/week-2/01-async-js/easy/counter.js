let counter = 0;
setInterval(() => {
  console.clear();
  console.log(counter);
  counter++;
}, 1000);
